import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

public class LondonMetShop extends JFrame implements ActionListener {
    private ArrayList<Gadget> gadgets = new ArrayList<>();

    private JTextField modelField, priceField, weightField, sizeField, creditField, memoryField, phoneNumberField, durationField, downloadSizeField, displayNumberField;

    public LondonMetShop() {
        gadgets = new ArrayList<>();
        setTitle(" LONDON MET GADGET SHOP");
        setLayout(new GridLayout(14,2));
        getContentPane().setBackground(new Color(0,0,0));

        JLabel modelLabel = new JLabel("Model:");
        modelLabel.setForeground(Color.RED);
        add(modelLabel);
        modelField = new JTextField();
        modelField.setForeground(Color.BLACK);
        modelField.setBackground(Color.YELLOW);
        add(modelField);

        JLabel priceLabel = new JLabel("Price (Â£):");
        priceLabel.setForeground(new Color(255,0,0));
        add(priceLabel);
        priceField = new JTextField();
        priceField.setForeground(Color.BLACK);
        priceField.setBackground(Color.YELLOW);
        add(priceField);

        JLabel weightLabel = new JLabel("Weight (grams):");
        weightLabel.setForeground(Color.RED);
        add(weightLabel);
        weightField = new JTextField();
        weightField.setForeground(Color.BLACK);
        weightField.setBackground(Color.YELLOW);
        add(weightField);

        JLabel sizeLabel = new JLabel("Size:");
        sizeLabel.setForeground(new Color (255,0,0));
        add(sizeLabel);
        sizeField = new JTextField();
        sizeField.setForeground(Color.BLACK);
        sizeField.setBackground(Color.YELLOW);
        add(sizeField);

        JLabel creditLabel = new JLabel("Initial Credit:");
        creditLabel.setForeground(Color.RED);
        add(creditLabel);
        creditField = new JTextField();
        creditField.setForeground(Color.BLACK);
        creditField.setBackground(Color.YELLOW);
        add(creditField);

        JLabel memoryLabel = new JLabel("Initial Memory (MB):");
        memoryLabel.setForeground(new Color(255,0,0));
        add(memoryLabel);
        memoryField = new JTextField();
        memoryField.setForeground(Color.BLACK);
        memoryField.setBackground(Color.YELLOW);
        add(memoryField);

        JLabel phoneNumberLabel = new JLabel("phoneNumber Number:");
        phoneNumberLabel.setForeground(Color.RED);
        add(phoneNumberLabel);
        phoneNumberField = new JTextField();
        phoneNumberField.setForeground(Color.BLACK);
        phoneNumberField.setBackground(Color.YELLOW);
        add(phoneNumberField);

        JLabel durationLabel = new JLabel("Duration (minutes):");
        durationLabel.setForeground(new Color(255,0,0));
        add(durationLabel);
        durationField = new JTextField();
        durationField.setForeground(Color.BLACK);
        durationField.setBackground(Color.YELLOW);
        add(durationField);

        JLabel downloadSizeLabel = new JLabel("Download Size (MB):");
        downloadSizeLabel.setForeground(Color.RED);
        add(downloadSizeLabel);
        downloadSizeField = new JTextField();
        downloadSizeField.setForeground(Color.BLACK);
        downloadSizeField.setBackground(Color.YELLOW);
        add(downloadSizeField);

        JLabel displayNumberLabel = new JLabel("Display Number:");
        displayNumberLabel.setForeground(new Color(255,0,0));
        add(displayNumberLabel);displayNumberField = new JTextField();
        displayNumberField.setForeground(Color.BLACK);
        displayNumberField.setBackground(Color.YELLOW);
        add(displayNumberField);

        JButton addMobileButton = new JButton("Add Mobile");
        addMobileButton.setForeground(Color.WHITE);
        addMobileButton.setBackground(new Color(255,192,203));
        addMobileButton.setOpaque(true);
        addMobileButton.setBorderPainted(false);
        addMobileButton.setFocusPainted(false);
        addMobileButton.addActionListener(this);
        add(addMobileButton);

        JButton addMP3Button = new JButton("Add MP3");
        addMP3Button.setForeground(Color.WHITE);
        addMP3Button.setBackground(new Color(128,0,128));
        addMP3Button.setOpaque(true);
        addMP3Button.setBorderPainted(false);
        addMP3Button.setFocusPainted(false);
        addMP3Button.addActionListener(this);
        add(addMP3Button);

        JButton addClearButton = new JButton("Clear");
        addClearButton.setForeground(Color.WHITE);
        addClearButton.setBackground(new Color(128,0,128));
        addClearButton.setOpaque(true);
        addClearButton.setBorderPainted(false);
        addClearButton.setFocusPainted(false);
        addClearButton.addActionListener(this);
        add(addClearButton);

        JButton addDisplayAllButton = new JButton("Display All");
        addDisplayAllButton.setForeground(Color.WHITE);
        addDisplayAllButton.setBackground(new Color(255,192,203));
        addDisplayAllButton.setOpaque(true);
        addDisplayAllButton.setBorderPainted(false);
        addDisplayAllButton.setFocusPainted(false);
        addDisplayAllButton.addActionListener(this);
        add(addDisplayAllButton);

        JButton addMakeCallButton = new JButton("Make A Call");
        addMakeCallButton.setForeground(Color.WHITE);
        addMakeCallButton.setBackground(new Color(255,192,203));
        addMakeCallButton.setOpaque(true);
        addMakeCallButton.setBorderPainted(false);
        addMakeCallButton.setFocusPainted(false);
        addMakeCallButton.addActionListener(this);
        add(addMakeCallButton);

        JButton addDownloadMusicButton = new JButton("Download Music");
        addDownloadMusicButton.setForeground(Color.WHITE);
        addDownloadMusicButton.setBackground(new Color(128,0,128));
        addDownloadMusicButton.setOpaque(true);
        addDownloadMusicButton.setBorderPainted(false);
        addDownloadMusicButton.setFocusPainted(false);
        addDownloadMusicButton.addActionListener(this);
        add(addDownloadMusicButton);

        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Add Mobile")) {
            addMobile();
        }
        else if (command.equals("Add MP3")) {
            addMP3();
        }
        else if (command.equals("Clear")) {
            clearFields();
        }
        else if (command.equals("Display All")) {
            displayAll();
        }
        else if (command.equals("Make A Call")) {
            makeCall();
        }
        else if (command.equals("Download Music")) {
            downloadMusic();
        }
    }

    private void addMobile() {
        String model = modelField.getText();
        double price = Double.parseDouble(priceField.getText());
        int weight = Integer.parseInt(weightField.getText());
        String size = sizeField.getText();
        int credit = Integer.parseInt(creditField.getText());Mobile mobile = new Mobile(model, price, weight, size, credit);
        gadgets.add(mobile);
        System.out.println("Mobile added: " + model);
    }

    private void addMP3() {
        String model = modelField.getText();
        double price = Double.parseDouble(priceField.getText());
        int weight = Integer.parseInt(weightField.getText());
        String size = sizeField.getText();
        int memory = Integer.parseInt(memoryField.getText());

        MP3 mp3 = new MP3(model, price, weight, size, memory);
        gadgets.add(mp3);
        System.out.println("MP3 added: " + model);
    }

    private void clearFields() {
        modelField.setText("");
        priceField.setText("");
        weightField.setText("");
        sizeField.setText("");
        creditField.setText("");
        memoryField.setText("");
        phoneNumberField.setText("");
        durationField.setText("");
        downloadSizeField.setText("");
        displayNumberField.setText("");
    }

    private void displayAll() {
        int displayNumber;
        try {
            displayNumber = Integer.parseInt(displayNumberField.getText().trim());
            if (displayNumber < 0 || displayNumber >= gadgets.size()) {
                JOptionPane.showMessageDialog(null, "Invalid display number:( enter a vaild number.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Display number must be an integer.");
            return;
        }

        for (int i = 0; i < gadgets.size(); i++) {
            gadgets.get(i).display();
            System.out.println("Display Number: " + i);
            System.out.println();
        }
    }

    private void makeCall() {
        int displayNumber = getDisplayNumber();
        if (displayNumber == -1) return;

        String phoneNumber = phoneNumberField.getText().trim();
        int duration;
        try {
            duration = Integer.parseInt(durationField.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid duration in minutes.");
            return;
        }

        Gadget gadget = gadgets.get(displayNumber);
        if (gadget instanceof Mobile) {
            Mobile mobile = (Mobile) gadget;
            mobile.makeACall(phoneNumber,duration);
        } else {
            JOptionPane.showMessageDialog(null, "Selected gadget is not a mobile.");
        }
    }

    private int getDisplayNumber() {
        try {
            int displayNumber = Integer.parseInt(displayNumberField.getText().trim());
            if (displayNumber < 0 || displayNumber >= gadgets.size()) {
                JOptionPane.showMessageDialog(null, "Invalid display number.");
                return -1;
            }
            return displayNumber;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Display number must be an integer.");
            return -1;
        }
    }

    private void downloadMusic() {
        int displayNumber = getDisplayNumber();
        if (displayNumber == -1) return;

        int downloadSize;
        try {
            downloadSize = Integer.parseInt(downloadSizeField.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid download size in MB.");
            return;
        }

        Gadget gadget = gadgets.get(displayNumber);
        if (gadget instanceof MP3) {
            MP3 mp3 = (MP3) gadget;
            mp3.downloadMusic(downloadSize);
        } else {
            JOptionPane.showMessageDialog(null, "Selected gadget is not an MP3 player.");
        }
    }

    public static void main(String[] args) {
      LondonMetShop LondonMetShop =  new LondonMetShop();
    }
}